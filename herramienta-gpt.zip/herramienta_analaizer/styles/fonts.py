from enum import Enum

class Font(Enum):
    DEFAULT="Poppins"