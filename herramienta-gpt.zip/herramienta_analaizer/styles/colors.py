from enum import Enum

class Color(Enum):
    ACCENT="#013047"
    PRIMARY="#FFFFFF"
    SECONDARY="#e36414"
    
class TextColor(Enum):
    ACCENT="#013047"
    PRIMTARY="#e36414"
